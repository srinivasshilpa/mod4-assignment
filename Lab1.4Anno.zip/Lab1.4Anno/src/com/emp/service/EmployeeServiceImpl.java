package com.emp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.bean.Employee;
import com.emp.dao.IEmployeeDAO;
@Service
public class EmployeeServiceImpl implements IEmployeeService {

    @Autowired
	IEmployeeDAO employeeDAO;
	
	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	@Override
	public void addEmployee(Employee emp) {
		
		employeeDAO.addEmployee(emp);
	}

	public Employee searchEmployee(int employeeId)
	{
		return  employeeDAO.searchEmployee(employeeId);
	}

}
