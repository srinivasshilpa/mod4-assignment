package com.emp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.emp.bean.Employee;
import com.emp.service.IEmployeeService;

@Component
public class EmployeeController {
	
	@Autowired
	IEmployeeService employeeService;
	
	
	
	public IEmployeeService getEmployeeService() {
		return employeeService;
	}



	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}



	public void addEmployee(Employee emp)
	{
		employeeService.addEmployee(emp);
	}
	
	public Employee searchEmployee(int employeeId)
	{
		return  employeeService.searchEmployee(employeeId);
	}
}
