package com.emp.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.emp.bean.Employee;
import com.emp.controller.EmployeeController;

public class TestApp {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		EmployeeController controller=(EmployeeController) ctx.getBean("employeeController");
		Employee emp=new Employee();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		int employeeId=sc.nextInt();
		
		emp=controller.searchEmployee(employeeId);
		
		System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName());
		sc.close();
	}

}
