package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import com.emp.bean.Employee;

public class EmployeeDAOImpl implements IEmployeeDAO {

	Map<Integer,Employee> map=new HashMap<Integer,Employee>();
	
	
	
	public Map<Integer, Employee> getMap() {
		return map;
	}



	public void setMap(Map<Integer, Employee> map) {
		this.map = map;
	}



	@Override
	public void addEmployee(Employee emp) {
		map.put(emp.getEmployeeId(), emp);
	}

	public Employee searchEmployee(int employeeId)
	{
		return  map.get(employeeId);
	}
}
